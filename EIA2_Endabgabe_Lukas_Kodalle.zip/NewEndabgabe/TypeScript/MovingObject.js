var Endgame;
(function (Endgame) {
    class MovingObject {
        draw() {
            //
        }
        move() {
            //
        }
        update() {
            this.move();
            this.draw();
        }
    }
    Endgame.MovingObject = MovingObject;
})(Endgame || (Endgame = {}));
//# sourceMappingURL=MovingObject.js.map